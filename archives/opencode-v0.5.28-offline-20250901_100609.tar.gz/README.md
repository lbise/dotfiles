# OpenCode Offline Package

This package contains a pre-built opencode installation with all dependencies for offline deployment.

## Contents

- `.opencode/bin/opencode` - The opencode executable
- `.cache/opencode/` - Pre-installed AI SDK dependencies
- `install.sh` - Installation script
- `README.md` - This file

## Installation

1. Extract this package:
   ```bash
   tar -xzf opencode-v0.5.28-offline-20250901_100609.tar.gz
   cd opencode-offline-*
   ```

2. Run the installation script:
   ```bash
   ./install.sh
   ```

3. Restart your shell or run:
   ```bash
   source ~/.bashrc  # or ~/.zshrc
   ```

## Manual Installation

If you prefer manual installation:

1. Copy files to your home directory:
   ```bash
   cp -r .opencode ~/
   cp -r .cache ~/
   chmod +x ~/.opencode/bin/opencode
   ```

2. Add to your PATH:
   ```bash
   export PATH="$HOME/.opencode/bin:$PATH"
   ```

## Usage

After installation, you can use opencode normally:
```bash
opencode --help
opencode auth login
```

## Package Info

- Created: Mon Sep  1 10:06:12 CEST 2025
- Source: Docker image 'ch03git.phonak.com/13lbise/devenv:latest'
- Includes pre-cached AI SDK dependencies for offline use
