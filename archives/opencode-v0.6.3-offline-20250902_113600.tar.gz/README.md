# OpenCode Offline Package

This package contains a pre-built opencode installation with all dependencies for offline deployment.

## Contents

- `.opencode/bin/opencode` - The opencode executable
- `.cache/opencode/` - Pre-installed AI SDK dependencies
- `install.sh` - Installation script
- `README.md` - This file

Note: This package only includes the binary and cache. The ~/.local/share/opencode folder is excluded and will remain untouched during installation.

## Installation

1. Extract this package:
   ```bash
   tar -xzf opencode-v0.6.3-offline-20250902_113600.tar.gz
   cd opencode-offline-*
   ```

2. Run the installation script:
   ```bash
   ./install.sh
   ```

3. Restart your shell or run:
   ```bash
   source ~/.bashrc  # or ~/.zshrc
   ```

## Manual Installation

If you prefer manual installation:

1. Copy files to your home directory:
   ```bash
   cp -r .opencode ~/
   cp -r .cache ~/
   chmod +x ~/.opencode/bin/opencode
   ```

2. Add to your PATH:
   ```bash
   export PATH="\$HOME/.opencode/bin:\$PATH"
   ```

## Usage

After installation, you can use opencode normally:
```bash
opencode --help
opencode auth login
```

## Package Info

- Created: Tue Sep  2 11:36:01 CEST 2025
- Source: Local machine
- Includes pre-cached AI SDK dependencies for offline use
- Excludes ~/.local/share/opencode folder (preserved during installation)
