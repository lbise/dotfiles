#!/usr/bin/env bash

set -euo pipefail

INSTALL_DIR="${HOME}/.opencode"
CACHE_DIR="${HOME}/.cache"

echo "Installing opencode offline package..."

# Create directories
mkdir -p "$INSTALL_DIR/bin"
mkdir -p "$CACHE_DIR"

# Copy files
cp -r .opencode/* "$INSTALL_DIR/"
cp -r .cache/* "$CACHE_DIR/"

# Make executable
chmod +x "$INSTALL_DIR/bin/opencode"

# Add to PATH if not already there
SHELL_RC=""
if [[ -f "$HOME/.bashrc" ]]; then
    SHELL_RC="$HOME/.bashrc"
elif [[ -f "$HOME/.zshrc" ]]; then
    SHELL_RC="$HOME/.zshrc"
fi

if [[ -n "$SHELL_RC" ]]; then
    if ! grep -q "\.opencode/bin" "$SHELL_RC"; then
        echo 'export PATH="$HOME/.opencode/bin:$PATH"' >> "$SHELL_RC"
        echo "Added opencode to PATH in $SHELL_RC"
        echo "Run 'source $SHELL_RC' or restart your shell to use opencode"
    fi
fi

echo "Installation complete!"
echo "opencode executable installed to: $INSTALL_DIR/bin/opencode"
echo "Cached dependencies installed to: $CACHE_DIR/opencode"

# Test installation
if command -v opencode >/dev/null 2>&1; then
    echo "✓ opencode is available in PATH"
else
    echo "⚠ opencode not found in PATH. You may need to restart your shell or run:"
    echo "  export PATH=\"\$HOME/.opencode/bin:\$PATH\""
fi
